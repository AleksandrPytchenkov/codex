﻿using Microsoft.AspNetCore.Identity;

namespace WebApplication.Data
{
    public class DataInitializer
    {
        public static async Task Initialize(IServiceProvider serviceProvider)
        {
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = serviceProvider.GetRequiredService<UserManager<ApplicationUser>>();

            string[] roleNames = { "просмотр всех поручений", "просмотр всех документов", "управление поручениями", "управление документами", "управление планёркой", "управление сотрудниками", "просмотр лога" };

            foreach (var roleName in roleNames)
            {
                if (!await roleManager.RoleExistsAsync(roleName))
                {
                    await roleManager.CreateAsync(new IdentityRole(roleName));
                }
            }

            string email1 = "admin@example.com";
            string email2 = "user@example.com";

            if (await userManager.FindByEmailAsync(email1) == null)
            {
                var user = new ApplicationUser
                {
                    UserName = email1,
                    Email = email1,
                    EmailConfirmed = true,
                    FirstName = "Admin",
                    LastName = "User",
                    MiddleName = "Userovich",
                    Position = "Ingener"
                };
                var result = await userManager.CreateAsync(user, "Password123!");
                if (result.Succeeded)
                {
                    await userManager.AddToRolesAsync(user, roleNames);
                }
            }

            if (await userManager.FindByEmailAsync(email2) == null)
            {
                var user = new ApplicationUser
                {
                    UserName = email2,
                    Email = email2,
                    EmailConfirmed = true,
                    FirstName = "Regular",
                    LastName = "User",
                    Position = "Nachalnik"
                };
                await userManager.CreateAsync(user, "Password123!");
            }
        }
    }
}
