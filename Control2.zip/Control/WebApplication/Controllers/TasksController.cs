using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication.Controllers
{
    [Authorize]
    public class TasksController : Controller
    {
        public IActionResult Current()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}
