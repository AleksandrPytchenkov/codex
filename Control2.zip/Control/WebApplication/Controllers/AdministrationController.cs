﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.Data;
using WebApplication.Models;

public class AdministrationController : Controller
{
    private readonly UserManager<ApplicationUser> _userManager;

    public AdministrationController(UserManager<ApplicationUser> userManager)
    {
        _userManager = userManager;
    }

    [HttpGet]
    public IActionResult Employees()
    {
        var users = _userManager.Users
            .Where(u => u.LockoutEnd == null)
            .Select(u => new EmployeeViewModel
            {
                Id = u.Id,
                LastName = u.LastName,
                FirstName = u.FirstName,
                MiddleName = u.MiddleName,
                Position = u.Position,
                Email = u.Email
            }).ToList();

        return View(users);
    }

    [HttpGet]
    public async Task<IActionResult> Employee(string id)
    {
        if (string.IsNullOrEmpty(id))
        {
            // Добавление нового пользователя
            return View(new EmployeeViewModel());
        }
        else
        {
            // Редактирование существующего пользователя
            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            var model = new EmployeeViewModel
            {
                Id = user.Id,
                LastName = user.LastName,
                FirstName = user.FirstName,
                MiddleName = user.MiddleName,
                Position = user.Position,
                Email = user.Email
            };

            return View(model);
        }
    }

    [HttpPost]
    public async Task<IActionResult> Employee(EmployeeViewModel model)
    {
        if (ModelState.IsValid)
        {
            if (string.IsNullOrEmpty(model.Id))
            {
                // Добавление нового пользователя
                var user = new ApplicationUser
                {
                    UserName = model.Email,
                    Email = model.Email,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    MiddleName = model.MiddleName,
                    Position = model.Position,
                    EmailConfirmed = true
                };
                var result = await _userManager.CreateAsync(user, "DefaultPassword123!");

                if (result.Succeeded)
                {
                    return RedirectToAction(nameof(Employees));
                }
            }
            else
            {
                // Редактирование существующего пользователя
                var user = await _userManager.FindByIdAsync(model.Id);
                if (user == null)
                {
                    return NotFound();
                }

                user.FirstName = model.FirstName;
                user.LastName = model.LastName;
                user.MiddleName = model.MiddleName;
                user.Position = model.Position;
                user.Email = model.Email;
                user.UserName = model.Email;

                var result = await _userManager.UpdateAsync(user);

                if (result.Succeeded)
                {
                    return RedirectToAction(nameof(Employees));
                }
            }
        }

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Block(string id)
    {
        var user = await _userManager.FindByIdAsync(id);
        if (user != null)
        {
            user.LockoutEnd = DateTimeOffset.UtcNow.AddYears(100);
            await _userManager.UpdateAsync(user);
        }
        return RedirectToAction(nameof(Employees));
    }
}