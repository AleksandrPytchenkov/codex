﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication.Controllers
{
    public class AdministrationController : Controller
    {
        public IActionResult Employees() => View();

        public IActionResult Priority() => View();
    }
}
