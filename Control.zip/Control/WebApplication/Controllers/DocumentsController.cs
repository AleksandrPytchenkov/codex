﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication.Controllers
{
    public class DocumentsController : Controller
    {
        public IActionResult Valid() => View();

        public IActionResult Archive() => View();
    }
}
