﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication.Controllers
{
    public class ActivityController : Controller
    {
        public IActionResult Log() => View();
    }
}
