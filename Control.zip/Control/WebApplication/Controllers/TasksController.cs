﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication.Controllers
{
    public class TasksController : Controller
    {
        [Authorize]
        public IActionResult Current() => View();

        public IActionResult Meeting() => View();

        public IActionResult History() => View();
    }
}
