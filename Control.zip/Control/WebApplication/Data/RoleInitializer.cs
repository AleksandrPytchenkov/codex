﻿using Microsoft.AspNetCore.Identity;

namespace WebApplication.Data
{
    public class RoleInitializer
    {
        public static async Task InitializeAsync(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            string[] roleNames = { "Просмотр всех поручений", "Просмотр всех документов", "Управление поручениями", "Управление документами", "Управление сотрудниками", "Управление планёркой", "Просмотр лога" };
            IdentityResult roleResult;

            foreach (var roleName in roleNames)
            {
                var roleExist = await roleManager.RoleExistsAsync(roleName);
                if (!roleExist)
                {
                    roleResult = await roleManager.CreateAsync(new IdentityRole(roleName));
                }
            }
        }
    }
}
