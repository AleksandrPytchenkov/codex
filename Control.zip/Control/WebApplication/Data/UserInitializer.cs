﻿using Microsoft.AspNetCore.Identity;

namespace WebApplication.Data
{
    public class UserInitializer
    {
        public static async Task InitializeAsync(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            string adminEmail = "admin@example.com";
            string adminPassword = "Admin@1234";
            string adminLastName = "Пытченков";
            string adminFirstName = "Александр";
            string adminMiddleName = "Юрьевич";
            string adminPosition = "Инженер 1 категории";

            string userEmail = "user@example.com";
            string userPassword = "User@1234";
            string userLastName = "Клибашев";
            string userFirstName = "Станислав";
            string userPosition = "Начальник УПР";

            if (await userManager.FindByEmailAsync(adminEmail) == null)
            {
                var adminUser = new ApplicationUser { UserName = adminEmail, Email = adminEmail, LastName = adminLastName, FirstName = adminFirstName, MiddleName = adminMiddleName, Position = adminPosition };
                var result = await userManager.CreateAsync(adminUser, adminPassword);
                if (result.Succeeded)
                {
                    var roles = roleManager.Roles.Select(r => r.Name).ToList();
                    await userManager.AddToRolesAsync(adminUser, roles);
                }
            }

            if (await userManager.FindByEmailAsync(userEmail) == null)
            {
                var regularUser = new ApplicationUser { UserName = userEmail, Email = userEmail, LastName = userLastName, FirstName = userFirstName, Position = userPosition };
                await userManager.CreateAsync(regularUser, userPassword);
                // Нет ролей для обычного пользователя
            }
        }
    }
}
